function mouseEnterLabrador(obj) {
	obj.innerHTML = "<a href='https://www.akc.org/expert-advice/lifestyle/22-photos-of-labrador-retriever-puppies-to-brighten-your-day/' target='_blank'>Click Here for More Information</a>"
}

function mouseLeaveLabrador(obj) {
	obj.innerHTML = "More Baby Labrador Pictures"
}

function mouseEnterPomeranian(obj) {
	obj.innerHTML = "<a href='https://www.pinterest.com/edieguidryfleck/pomeranian-puppy/' target='_blank'>Click Here for More Information</a>"
}

function mouseLeavePomeranian(obj) {
	obj.innerHTML = "More Baby Pomeranian Pictures"
}

function mouseEnterPug(obj) {
	obj.innerHTML = "<a href='https://www.pinterest.com/haagleslie/baby-pugs/' target='_blank'>Click Here for More Information</a>"
}

function mouseLeavePug(obj) {
	obj.innerHTML = "More Baby Pug Pictures"
}