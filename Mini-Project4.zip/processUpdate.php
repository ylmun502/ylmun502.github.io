<?php
	if(!isset($_SESSION))
		session_start();
	
	function convertHTML($data) {
		return htmlspecialchars($data);
	}
	
	$password = $email = $address = $fullname = $age = "";
	$emailError = $nameError = "";
	$isError = false;
	
	if($_SERVER["REQUEST_METHOD"] == "POST") {
		
		if (!empty($_POST["password"]))
			$password = convertHTML($_POST["password"]);
		
		if (!empty($_POST["email"])) {
			$email = convertHTML($_POST["email"]);
			if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				$emailError = "*Invalid email format";
				$isError = true;
			}
		}
		
		if(!empty($_POST["address"]))
			$address = convertHTML($_POST["address"]);
		
		if(!empty($_POST["fullname"])) {
			$fullname = convertHTML($_POST["fullname"]);
			if (!preg_match("/^[a-zA-Z ]*$/", $fullname)) {
				$nameError = "*Only letters and white space are allowed";
				$isError = true;
			}
		}
		
		if(!empty($_POST["age"]))
			$age = convertHTML($_POST["age"]);
	}
	if(!$isError) {
		$dsn = "mysql:host=localhost;dbname=cs351";
		$dbUser = "cs351";
		$dbPassword = "password";
	
		try {
			$id = $_SESSION["username"];
			$db = new PDO($dsn, $dbUser, $dbPassword);
			$query = "SELECT * FROM users WHERE username = :username";
			$stmt = $db->prepare($query);
			$stmt->bindValue('username', $id);
			$stmt->execute();
			$record = $stmt->fetch();
			if(empty($password))
				$password = $record["uPassword"];
			if(empty($email))
				$email = $record["email"];
			if(empty($address))
				$address = $record["address"];
			if(empty($fullname))
				$fullname = $record["fullname"];
			if(empty($age))
				$age = $record["age"];
			$query = "UPDATE users SET uPassword = :password, ".
					 "email = :email, address = :address, fullname = :fullname, ".
					 "age = :age WHERE username = :username";
			$stmt = $db->prepare($query);
			$stmt->bindValue("username", $id);
			$stmt->bindValue("password", $password);
			$stmt->bindValue("email", $email);
			$stmt->bindValue("address", $address);
			$stmt->bindValue("fullname", $fullname);
			$stmt->bindValue("age", $age);
			$stmt->execute();
			$stmt->closeCursor();
			echo nl2br("Your profile is updated.");
		}
		catch(PDOException $e) {
				$error	 = "Unable to connect to the database: ".$e->getMessage();
				include('index.php');
				exit(0);
		}
	}
	include("updateProfile.php");
	exit(0);
?>