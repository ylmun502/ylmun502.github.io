<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css">
		<meta charset="utf-8">
		<meta name="description" content="Submit the user information for account registration">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="website devlopment, HTML, CSS">
		<meta name="author" content="Mun">
		<title>Account Registration</title>
	</head>
	<body>
		<header>
			<t>** Account Registration**</t>
			<hr>
			<nav>
				<div class="navAlign">
					<ul class="listFormat">
						<li>
							<a href="galleryHome.html">Home</a>
						</li>
						<li>
							<div class="navDropDown"> 
							<button class="dropButton">My Favorite</button>
								<div class="dropDownContent">
									<a href="LabradorRetriever.html">Labrador Retriever</a> <!-- clickable link -->
									<a href="Pomeranian.html">Pomeranian</a>
									<a href="Pug.html">Pug</a>
							</div>
						</li>
						<li>
							<a href="contactUs.php">Contact Us</a>
						</li>
						<li>
							<a href="index.php">Sign In</a>
						</li>
						<li>
							<a href="account.php">Account</a>
						</li>
					</ul>
				</div>
			</nav>
			<hr>
		</header>
		<h3>Account Registration Form</h3>
		<p>All fields are required</p>
		<form action="dbRegistration.php" method="POST">
			<strong>Username:</strong> <input type="text" name="id" placeholder="Enter your username" value="<?php echo (isset($id) ? $id : "");?>">
			<span><?php echo (empty($usernameError) ? "" : $usernameError);?></span><br/><br/>
			<strong>Password:</strong> <input type="password" name="password" placeholder="Enter your password" value="">
			<span><?php echo (empty($passwordError) ? "" : $passwordError);?></span><br/><br/>
			<strong>Email:</strong> <input type="email" name="email" placeholder="Enter your email" value="<?php echo (isset($email) ? $email : "");?>">
			<span><?php echo (empty($emailError) ? "" : $emailError);?></span><br/><br/>
			<strong>Address:</strong> <input type="text" name="address" placeholder="Enter your address" value="<?php echo (isset($address) ? $address : "");?>">
			<span><?php echo (empty($addressError) ? "" : $addressError);?></span><br/><br/>
			<strong>Name:</strong> <input type="text" name="fullname" placeholder="Enter your name" value="<?php echo (isset($fullname) ? $fullname : "");?>">
			<span><?php echo (empty($nameError) ? "" : $nameError);?></span><br/><br/>
			<strong>Age:</strong> <input type="number" min="0" name="age" placeholder="Enter your age" value="<?php echo (isset($age) ? $age : "");?>">
			<span><?php echo (empty($ageError) ? "" : $ageError);?></span><br/><br/>
			<input type="submit" name="submit" value="Submit"><br/>
		</form>
		<p>
		<?php
			if (isset($message) && $message !== "")
				echo nl2br("ERROR: ".htmlspecialchars($message)."\r\n");
			if (isset($messageUsername) && $messageUsername !== "")
				echo nl2br("ERROR: ".htmlspecialchars($messageUsername)."\r\n");
			if (isset($messageEmail) && $messageEmail !== "")
				echo "ERROR: ".htmlspecialchars($messageEmail);
		?>
		</p>
		<hr>
		<footer class="footer">
			<p>Copyright &copy; 2020</p>
		</footer>
	</body>
</html>