<!doctype html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css">
		<meta charset="utf-8">
		<meta name="description" content="Login into an account">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="website devlopment, HTML, CSS">
		<meta name="author" content="Mun">
		<title>Login Page</title>
	</head>
	<body>
		<header>
			<t>** Login **</t>
			<hr>
			<nav>
				<div class="navAlign">
					<ul class="listFormat">
						<li>
							<a href="galleryHome.html">Home</a>
						</li>
						<li>
							<div class="navDropDown"> 
							<button class="dropButton">My Favorite</button>
								<div class="dropDownContent">
									<a href="LabradorRetriever.html">Labrador Retriever</a> <!-- clickable link -->
									<a href="Pomeranian.html">Pomeranian</a>
									<a href="Pug.html">Pug</a>
							</div>
						</li>
						<li>
							<a href="accountRegistration.php">Sign Up</a>
						</li>
						<li>
							<a href="account.php">Account</a>
						</li>
						<li>
							<a href="contactUs.php">Contact Us</a>
						</li>
					</ul>
				</div>
			</nav>
			<hr>
		</header>
		<form action="processLogin.php" method="POST">
			<strong>Username:</strong> <input type="text" name="id" placeholder="Enter your username" value="<?php echo (isset($id) ? $id : "");?>">
			<span><?php echo (empty($usernameError) ? "" : $usernameError);?></span><br/><br/>
			<strong>Password:</strong> <input type="password" name="password" placeholder="Enter your password" value="">
			<span><?php echo (empty($passwordError) ? "" : $passwordError);?></span><br/><br/>
			<input type="submit" name="submit" value="Submit"><br/>
		</form>
		<?php
			if(isset($message) && $message !== "")
				echo nl2br(htmlspecialchars($message));
		?>
		<hr>
		<br/>
		<footer class="footer">
			<p>Copyright &copy; 2020</p>
		</footer>
	</body>
</html>