<?php
	session_start();
	function convertHTML($data) {
		return htmlspecialchars($data);
	}
	
	$dsn = "mysql:host=localhost;dbname=cs351";
	$dbUser = "cs351";
	$dbPassword = "password";
	
	$id = $password = "";
	$usernameError = $passwordError = "";
	$isError = False;
	
	if($_SERVER["REQUEST_METHOD"] === "POST") {
		if (empty($_POST["id"])) {
			$usernameError = "*Username is required";
			$isError = true;
		}
		else
			$id = convertHTML($_POST["id"]);
	
		if(empty($_POST["password"])) {
			$passwordError = "*Password is required";
			$isError = true;
		}
		else
			$password = convertHTML($_POST["password"]);
	}
	
	if(!$isError) {
			try {
				$db = new PDO($dsn, $dbUser, $dbPassword);
				$query = "SELECT username, uPassword FROM users WHERE username = :username";
				$stmt = $db->prepare($query);
				$stmt->bindValue('username', $id);
				$stmt->execute();
				$record = $stmt->fetch();
				$stmt->closeCursor();
				if(!$record)
					$message = "The username does not exist!";
				else if($record["uPassword"] != $password)
					$message = "The password is incorrect!";
				else {
					$_SESSION["username"] = $_POST["id"];
					header("Location:account.php");
					exit(0);
				}
			}
			catch(PDOException $e) {
					$error = "Unable to connect to the database: ".$e->getMessage();
					include('index.php');
					exit(0);
			}
	}
	include('index.php');
	exit(0);
?>