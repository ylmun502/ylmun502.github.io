<?php
	if(!isset($_SESSION))
		session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css">
		<meta charset="utf-8">
		<meta name="description" content="Login into an account">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="website devlopment, HTML, CSS">
		<meta name="author" content="Mun">
		<title>User Account</title>
	</head>
	<body>
		<header>
			<t>** User Account **</t>
			<hr>
			<nav>
				<div class="navAlign">
					<ul class="listFormat">
						<li>
							<a href="galleryHome.html">Home</a>
						</li>
						<li>
							<div class="navDropDown"> 
							<button class="dropButton">My Favorite</button>
								<div class="dropDownContent">
									<a href="LabradorRetriever.html">Labrador Retriever</a> <!-- clickable link -->
									<a href="Pomeranian.html">Pomeranian</a>
									<a href="Pug.html">Pug</a>
							</div>
						</li>						
						<li>
							<a href="accountRegistration.php">Sign Up</a>
						</li>
						<li>
							<a href="contactUs.php">Contact Us</a>
						</li>
					</ul>
				</div>
			</nav>
			<hr>
		</header>
		<?php
		if($_SESSION["username"])
			echo "Welcome ".$_SESSION["username"].". Have a good day and enjoy your stay!";
		else {
			$_SESSION["restricted"] = "Error! Restricted page! Please log in first.";
			header("Location:index.php");
			exit(0);
		}
		?>
		<br/><br/>
		<form action="viewProfile.php">
			<input type="submit" class="button" name="View Profile" value="View Profile"/>
		</form>
		<form action="updateProfile.php">
			<input type="submit" class="button" name="Update Profile" value="Update Profile"/>
		</form>
		<form action="logout.php">
			<input type="submit" class="button" name="Log Out" value="Log Out"/>
		</form>
	</body>
</html>