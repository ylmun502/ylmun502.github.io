<!doctype html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css">
		<meta charset="utf-8">
		<meta name="description" content="Account creation successfully">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="website devlopment, HTML, CSS">
		<meta name="author" content="Mun">
		<title>Registeration Successful Page</title>
	</head>
	<body>
		<h1>Registration Successful!</h1>
		<h2>
			<?php
				if(isset($message) && $message !== "")
					echo nl2br(htmlspecialchars($message));
			?>
			<p><a href="login.php">Click here to continue to the login page</a></p>
		</h2>
		<hr>
		<footer class="footer">
			<p>Copyright &copy; 2020</p>
		</footer>
	</body>
</html>