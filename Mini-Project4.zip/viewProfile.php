<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css">
		<meta charset="utf-8">
		<meta name="description" content="Login into an account">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="website devlopment, HTML, CSS">
		<meta name="author" content="Mun">
		<title>User Account</title>
	</head>
	<body>
		<header>
			<?php echo "<t>** ".$_SESSION["username"]." **</t>"; ?>
			<hr>
		</header>
		<?php
			$dsn = "mysql:host=localhost;dbname=cs351";
			$dbUser = "cs351";
			$dbPassword = "password";
			
			try {
				$db = new PDO($dsn, $dbUser, $dbPassword);
				$query = "SELECT * FROM users WHERE username = :username";
				$stmt = $db->prepare($query);
				$stmt->bindValue('username', $_SESSION["username"]);
				$stmt->execute();
				$record = $stmt->fetch();
				$stmt->closeCursor();
				echo nl2br("Username: ".$record["username"]."\r\n\r\nPassword: ".$record["uPassword"].
						   "\r\n\r\nEmail: ".$record["email"]."\r\n\r\nAddress: ".$record["address"].
						   "\r\n\r\nFullname: ".$record["fullname"]."\r\n\r\nAge: ".$record["age"]);
			}
			catch(PDOException $e) {
					$error	 = "Unable to connect to the database: ".$e->getMessage();
					include('index.php');
					exit(0);
			}
		?>

	<p><a href="account.php">Click here to go back to your account</a></p>
<html>