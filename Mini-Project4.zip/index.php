<?php
	session_start();
	if(!empty($_SESSION["username"]))
		require_once 'account.php'; 
	else {
		if(isset($_SESSION["signOut"])) {
			echo $_SESSION["signOut"];
			unset($_SESSION["signOut"]);
		}
		else if(isset($_SESSION["restricted"])) {
			echo $_SESSION["restricted"];
			unset($_SESSION["restricted"]);
		}
		require_once 'login.php';
	}
?>