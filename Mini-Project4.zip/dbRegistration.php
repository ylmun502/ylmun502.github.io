<?php
	function convertHTML($data) {
		return htmlspecialchars($data);
	}
	
	$dsn = "mysql:host=localhost;dbname=cs351";
	$dbUser = "cs351";
	$dbPassword = "password";

	$id = $password = $email = $address = $fullname = $age = "";
	$usernameError = $passwordError = $emailError = $addressError = $nameError = $ageError = "";
	$isError = $isUsernameExist = $isEmailExist = false;

	if($_SERVER["REQUEST_METHOD"] === "POST") {
		if (empty($_POST["id"])) {
			$usernameError = "*Username is required";
			$isError = true;
		}
		else
			$id = convertHTML($_POST["id"]);
	
		if(empty($_POST["password"])) {
			$passwordError = "*Password is required";
			$isError = true;
		}
		else
			$password = convertHTML($_POST["password"]);
		
		if(empty($_POST["email"])) {
			$emailError = "*Email is requried";
			$isError = true;
		}
		else {
			$email = convertHTML($_POST["email"]);
			if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				$emailError = "*Invalid email format";
				$isError = true;
			}
		}
		
		if(empty($_POST["address"])) {
			$addressError = "*Address is required";
			$isError = true;
		}
		else
			$address = convertHTML($_POST["address"]);
		
		if(empty($_POST["fullname"])) {
			$nameError = "*Name is required";
			$isError = true;
		}
		else {
			$fullname = convertHTML($_POST["fullname"]);
			if(!preg_match("/^[a-zA-Z ]*$/", $fullname)) {
				$nameError = "*Only letters and white space are allowed";
				$isError = true;
			}
		}
		
		if(empty($_POST["age"])) {
			$ageError = "*Age is required";
			$isError = true;
		}
		else
			$age = convertHTML($_POST["age"]);
	}
	
	if(!$isError) {
		try {
			$db = new PDO($dsn, $dbUser, $dbPassword);
			$usernameQuery = "SELECT username, uPassword, email, fullname, age FROM users WHERE username = :username";
			$stmt = $db->prepare($usernameQuery);
			$stmt->bindValue('username', $id);
			$stmt->execute();
			$usernameRecord = $stmt->fetch();
			$emailQuery = "SELECT email FROM users WHERE email = :email";
			$stmt = $db->prepare($emailQuery);
			$stmt->bindValue('email', $email);
			$stmt->execute();
			$emailRecord = $stmt->fetch();
			$stmt->closeCursor();
			if(!$usernameRecord && !$emailRecord) {
				$insertQuery = "INSERT INTO users (username, uPassword, email, address, fullname, age) ".
							"Values(:username, :password, :email, :address, :fullname, :age)";
				$stmt = $db->prepare($insertQuery);
				$stmt->bindValue("username", $id);
				$stmt->bindValue("password", $password);
				$stmt->bindValue("email", $email);
				$stmt->bindValue("address", $address);
				$stmt->bindValue("fullname", $fullname);
				$stmt->bindValue("age", $age);
				$stmt->execute();
			}
			if($usernameRecord["username"] === $id)
				$isUsernameExist = true;
			if($emailRecord["email"] === $email)
				$isEmailExist = true;
		} 
		catch(PDOException $e) {
			$error = "Unable to connect to the database: ".$e->getMessage();
			include('accountRegistration.php');
			exit(0);
		}
	}

	if($isError || $isUsernameExist || $isEmailExist) {
		$message = "One or more fields is/are mising!";
		if($isUsernameExist)
			$messageUsername = "The username is already taken! Please try another.";
		if($isEmailExist)
			$messageEmail = "The email is already taken! Please try another.";
		include("accountRegistration.php");
		exit(0);
	}
	else {
		include("registrationSuccessful.php");
		exit(0);
	}
?>