<?php
	session_start();
	$_SESSION["signOut"] = "You have successfully logged out. See you again!";
	unset($_SESSION["username"]);
	header("Location:index.php");
	exit(0);
?>