<?php
	if(!isset($_SESSION))
		session_start();
	if(!$_SESSION["username"]) {
		$_SESSION["restricted"] = "Error! Restricted page! Please log in first.";
		header("Location:index.php");
		exit(0);
	}
?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css">
		<meta charset="utf-8">
		<meta name="description" content="Submit the information of your dog">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="website devlopment, HTML, CSS">
		<meta name="author" content="Mun">
		<script src="jquery-3.4.1.js"></script>
		<script src="jquery-ui.js"></script>
		<script src="myJQuery.js"></script>
		<title>Contact Us</title>
	</head>
	<body>
		<header>
			<t>** Provide Your Dog's Information **</t>
			<hr>
			<nav>
				<div class="navAlign">
					<ul class="listFormat">
						<li>
							<a href="galleryHome.html">Home</a>
						</li>
						<li>
							<div class="navDropDown"> 
							<button class="dropButton">My Favorite</button>
								<div class="dropDownContent">
									<a href="LabradorRetriever.html">Labrador Retriever</a> <!-- clickable link -->
									<a href="Pomeranian.html">Pomeranian</a>
									<a href="Pug.html">Pug</a>
							</div>
						</li>
						<li>
							<a href="accountRegistration.php">Sign Up</a>
						</li>
						<li>
							<a href="account.php">Account</a>
						</li>
					</ul>
				</div>
			</nav>
			<hr>
		</header>
		<section>
			<form class="formStyle">
				<p>Complete the following boxes:</p>
				<p><strong>Name:</strong> <input type="text" placeholder="Enter your name" required><br/></p>
				<p>Date: <input type="text" id="datePicker" required><br/></p>
				<p><strong>Email:</strong> <input type="email" name="email" placeholder="Enter your email" required><br/></p>
				<p>Are you <em>male</em> or <em>female</em>?<br/></p>
				<p><input name="gender" type="radio">male<input name="gender" type="radio">female<br/></p>
				<input type="submit" value="Submit">
			</form>
			<hr>
			<p> Do you want to upload any picture about your doggie?<br/></p>
			<input type="file" name="doggiePicture"><button type="button" name="uploadButton" onclick="alert('Successfully Uploaded')">Upload</button><br/>
			<hr>
			<p>Tell us more about your cutie doggie:<br></p>
			<textarea name="name" rows="8" cols="50"></textarea>
			<button type="button" name="submitButton" onclick="alert('Sent')">Submit</button>
		</section>
		<footer class="footer">
			<p>Copyright &copy; 2020</p>
		</footer>
	</body>
</html>