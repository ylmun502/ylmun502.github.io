<?php
	if(!isset($_SESSION))
		session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css">
		<meta charset="utf-8">
		<meta name="description" content="Update user information">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="website devlopment, HTML, CSS">
		<meta name="author" content="Mun">
		<title>Update Profile</title>
	</head>
	<body>
		<header>
			<?php echo "<t>** ".$_SESSION["username"]." **</t>"; ?>
			<hr>
		</header>
		<h3>Profile Update Form</h3>
		<p>Only fill in the fields that you would like to update</p>
		<form action="processUpdate.php" method="POST">
			<strong>Password:</strong> <input type="password" name="password" placeholder="Enter your password" value=""><br/><br/>
			<strong>Email:</strong> <input type="email" name="email" placeholder="Enter your email" value=""><br/><br/>
			<span><?php echo (empty($emailError) ? "" : $emailError);?></span>
			<strong>Address:</strong> <input type="text" name="address" placeholder="Enter your address" value=""><br/><br/>
			<strong>Name:</strong> <input type="text" name="fullname" placeholder="Enter your name" value=""><br/><br/>
			<span><?php echo (empty($nameError) ? "" : $nameError);?></span>
			<strong>Age:</strong> <input type="number" min="0" name="age" placeholder="Enter your age" value=""><br/><br/>
			<input type="submit" name="submit" value="Submit"><br/>
		</form>
		<p><a href="account.php">Click here to go back to your account</a></p>
	</body>
<html>